from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


_TRAILING_ALSA_ID_RE = re.compile(r"\s+\d+:\d+$")
_TRAILING_INSTANCE_RE = re.compile(r"\s+\(\d+\)$")
_TRAILING_SIMPLE_PORT_RE = re.compile(r":\d+$")
_MULTISPACE_RE = re.compile(r"\s+")

_FAKE_RTP_NAMES = {
    "rtpmidid:announcements",
    "rtpmidid:network export",
}


class PortResolutionStatus(str, Enum):
    EXACT = "exact"
    RESOLVED_COMPATIBLE = "resolved_compatible"
    AUTO_SELECTED = "auto_selected"
    UNAVAILABLE = "unavailable"


@dataclass(frozen=True)
class PortResolution:
    requested_port: str | None
    selected_port: str | None
    status: PortResolutionStatus
    reason: str


def descriptive_port_name(port_name: str | None) -> str | None:
    if not port_name:
        return None

    normalized = port_name.strip()
    normalized = _TRAILING_ALSA_ID_RE.sub("", normalized)
    normalized = _TRAILING_INSTANCE_RE.sub("", normalized)

    if " " not in normalized:
        normalized = _TRAILING_SIMPLE_PORT_RE.sub("", normalized)

    normalized = _MULTISPACE_RE.sub(" ", normalized).strip()
    return normalized or None


def _stable_port_key(port_name: str | None) -> str:
    descriptive = descriptive_port_name(port_name) or ""
    return _MULTISPACE_RE.sub(" ", descriptive).strip().lower()


def _relaxed_port_key(port_name: str | None) -> str:
    key = _stable_port_key(port_name)
    key = key.replace("!", "")
    return key


def is_fake_rtp_port(port_name: str | None) -> bool:
    return _stable_port_key(port_name) in _FAKE_RTP_NAMES


def port_is_present(actual_port: str | None, available_ports: list[str]) -> bool:
    if not actual_port:
        return False

    actual_stable = _stable_port_key(actual_port)
    actual_relaxed = _relaxed_port_key(actual_port)

    for candidate in available_ports:
        if candidate == actual_port:
            return True
        if _stable_port_key(candidate) == actual_stable:
            return True
        if _relaxed_port_key(candidate) == actual_relaxed:
            return True
    return False


def pick_default_input_port(available_ports: list[str]) -> str | None:
    for port_name in available_ports:
        lowered = port_name.lower()
        if "through" in lowered or "rpi" in lowered:
            continue
        return port_name
    return available_ports[0] if available_ports else None


def pick_default_output_port(available_ports: list[str]) -> str | None:
    for port_name in available_ports:
        lowered = port_name.lower()
        if "through" in lowered or "rpi" in lowered:
            continue
        if is_fake_rtp_port(port_name):
            continue
        return port_name
    return None


def _resolve_port(requested_port: str | None, available_ports: list[str], *, exclude_fake_rtp: bool) -> PortResolution:
    if not requested_port or requested_port == "default":
        return PortResolution(
            requested_port=requested_port,
            selected_port=None,
            status=PortResolutionStatus.UNAVAILABLE,
            reason="No explicit port requested",
        )

    filtered_ports = [
        candidate for candidate in available_ports
        if not (exclude_fake_rtp and is_fake_rtp_port(candidate))
    ]

    if requested_port in filtered_ports:
        return PortResolution(
            requested_port=requested_port,
            selected_port=requested_port,
            status=PortResolutionStatus.EXACT,
            reason="Exact ALSA port match",
        )

    requested_stable = _stable_port_key(requested_port)
    requested_relaxed = _relaxed_port_key(requested_port)

    stable_matches = [candidate for candidate in filtered_ports if _stable_port_key(candidate) == requested_stable]
    if stable_matches:
        return PortResolution(
            requested_port=requested_port,
            selected_port=stable_matches[0],
            status=PortResolutionStatus.RESOLVED_COMPATIBLE,
            reason="Matched stable descriptive ALSA name",
        )

    relaxed_matches = [candidate for candidate in filtered_ports if _relaxed_port_key(candidate) == requested_relaxed]
    if relaxed_matches:
        return PortResolution(
            requested_port=requested_port,
            selected_port=relaxed_matches[0],
            status=PortResolutionStatus.RESOLVED_COMPATIBLE,
            reason="Matched relaxed RTP session name",
        )

    contains_matches = [
        candidate for candidate in filtered_ports
        if requested_relaxed and (
            requested_relaxed in _relaxed_port_key(candidate)
            or _relaxed_port_key(candidate) in requested_relaxed
        )
    ]
    if len(contains_matches) == 1:
        return PortResolution(
            requested_port=requested_port,
            selected_port=contains_matches[0],
            status=PortResolutionStatus.RESOLVED_COMPATIBLE,
            reason="Matched unique compatible RTP/ALSA port",
        )

    return PortResolution(
        requested_port=requested_port,
        selected_port=None,
        status=PortResolutionStatus.UNAVAILABLE,
        reason="Requested port is unavailable and no compatible runtime match was found",
    )


def resolve_input_port(requested_port: str | None, available_ports: list[str]) -> PortResolution:
    return _resolve_port(requested_port, available_ports, exclude_fake_rtp=False)


def resolve_output_port(requested_port: str | None, available_ports: list[str]) -> PortResolution:
    return _resolve_port(requested_port, available_ports, exclude_fake_rtp=True)
